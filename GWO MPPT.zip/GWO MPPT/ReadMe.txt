This folder contains the Simulink model of Grey wolf based MPPT to optimize PV energy



Please cite this work as: 

1. Motahhir, S., Chtita, S., Chouder, A., & Hammoumi, A. E. (2022). Enhanced energy output from a PV system under partial shaded conditions through Grey wolf optimizer. Cleaner Engineering and Technology (Elsevier), 100533.

2. Chtita, S., Motahhir, S., El Hammoumi, A., Chouder, A., Benyoucef, A. S., El Ghzizal, A., ... & Askar, S. S. (2022). A novel hybrid GWO–PSO-based maximum power point tracking for photovoltaic systems operating under partial shading conditions. Scientific Reports (Nature publication), 12(1), 1-15.

3. Motahhir, S., El Hammoumi, A., & El Ghzizal, A. (2020). The Most Used MPPT Algorithms: Review and the Suitable Low-cost Embedded Board for Each Algorithm. Journal of Cleaner Production (Elsevier), 118983.




For more papers and works please visit : https://sites.google.com/usmba.ac.ma/motahhir/home









